﻿for(var i = 0; i < 104; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u85'] = 'center';
$axure.eventManager.mouseover('u11', function(e) {
if (!IsTrueMouseOver('u11',e)) return;
if (true) {

}
});

$axure.eventManager.mouseout('u11', function(e) {
if (!IsTrueMouseOut('u11',e)) return;
if (true) {

}
});
gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u80'] = 'top';
﻿for(var i = 0; i < 38; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u34'] = 'center';